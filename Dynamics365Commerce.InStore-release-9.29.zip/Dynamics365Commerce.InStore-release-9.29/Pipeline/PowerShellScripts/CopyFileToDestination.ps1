param(
    [string]$RelativePath,
    [string]$File,
    [string]$DestinationFullName
)

$searchFile = Get-ChildItem -Path $RelativePath -Filter $File -Recurse
if (-NOT $searchFile) {
    throw "$File file was not found."
}
else {
    Copy-Item $searchFile.FullName -Destination "$DestinationFullName"
}