write-host "Executing pre-build scripts"

# Any additional scripts to be executed during pipeline should be referenced in this file
# Link for reference: https://docs.microsoft.com/en-us/powershell/module/microsoft.powershell.utility/invoke-expression?view=powershell-7.1

# Invoke-Expression -Command "C:\ps-test\testscript.ps1"